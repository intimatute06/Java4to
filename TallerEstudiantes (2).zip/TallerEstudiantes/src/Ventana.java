import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;

public class Ventana {
    private JPanel Principal;
    private JTextArea txtNombre;
    private JTextArea txtCalificacion;
    private JTextField txtId;
    private JButton btnAgregar;
    private JButton btnMostrar;
    private JButton btnBuscar;
    private JButton btnOrdenar;
    private JTextArea txtLista;
    private JButton btnAprobados;
    private JButton btnReprobado;
    private JButton btnEliminar;
    private JButton btnGuardarNOtas;

    GestorEstudiantes gestor = new GestorEstudiantes();

    public Ventana() {
        txtLista.setText(gestor.mostrarTodos());


        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText().trim();
                String notaStr = txtCalificacion.getText().trim();
                String idStr = txtId.getText().trim();
                if (nombre.isEmpty() || notaStr.isEmpty() || idStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null,"LLena Todos Los Campos");
                    return;
                }

                try{
                    double nota = Double.parseDouble(notaStr);
                    int id = Integer.parseInt(idStr);

                    if (id % 5 != 0){
                        JOptionPane.showMessageDialog(null,"El ID debe ser multiplo de 5");
                        return;

                    }
                    if (nota < 0 || nota > 10){
                        JOptionPane.showMessageDialog(null,"La nota debe estar entre 0 y 10");
                        return;
                    }
                    Estudiante nuevo = new Estudiante(nombre,nota,id);
                    boolean agregado = gestor.agregar(nuevo);
                    if (agregado){
                        JOptionPane.showMessageDialog(null,"Estudiante agregado");
                        txtLista.setText(gestor.mostrarTodos());
                    }else {
                        JOptionPane.showMessageDialog(null,"Ya existe un Estudiante con ese ID. ");
                    }
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(null,"ID y Nota Deben Ser Valores Validos");
                }
            }
        });
        btnMostrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtLista.setText(gestor.mostrarTodos());
            }
        });
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText().trim();
                if (nombre.isEmpty()){
                    JOptionPane.showMessageDialog(null,"Escribe un nombre para buscar");
                }else{
                    txtLista.setText(gestor.buscarPorNombre(nombre));
                }
            }
        });
        btnOrdenar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gestor.ordenarPorNotaDescendente();
                txtLista.setText(gestor.mostrarTodos());
            }
        });
        btnAprobados.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                txtLista.setText(gestor.listarAprobados());
            }
        });
        btnReprobado.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtLista.setText(gestor.listarReprobados());
            }
        });
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idStr = txtId.getText().trim();
                if(idStr.isEmpty()){
                    JOptionPane.showMessageDialog(null,"Ingrese el ID ");
                    return;
                }
                try {
                    int id = Integer.parseInt(idStr);
                    boolean eliminado = gestor.eliminarCodigo(id);
                    if(eliminado){
                        JOptionPane.showMessageDialog(null,"Estudiante Eliminado");
                        txtLista.setText(gestor.mostrarTodos());

                    }else{
                        JOptionPane.showMessageDialog(null,"No se encontro el ID");
                    }
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(null,"El ID debe ser Valido");
                }
            }
        });
        btnGuardarNOtas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    FileWriter fw = new FileWriter("C:\\Users\\NW\\Desktop\\Java 4to\\TallerEstudiantes\\NotasEs.txt");
                    for(Estudiante x: gestor.lista){
                        fw.write(x.toString() + "\n");

                    }
                    fw.close();
                    JOptionPane.showMessageDialog(null,"Notas Exportadas con exito");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null,"Error al guardar");
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }
}
