import java.util.ArrayList;

public class GestorEstudiantes {
    public ArrayList<Estudiante> lista = new ArrayList<>();

    public GestorEstudiantes() {
        lista.add(new Estudiante("Inti", 8.5, 5));
        lista.add(new Estudiante("LgSus", 7.0, 10));
        lista.add(new Estudiante("Valentina", 10.0, 15));

    }

    public boolean agregar(Estudiante x){
        for(Estudiante v: lista){
            if(v.getCodigo() == x.getCodigo()){
                return false;
            }
        }
        lista.add(x);
        return true;
    }

    public String mostrarTodos(){
        StringBuilder sb = new StringBuilder();
        for (Estudiante x: lista){
            sb.append(x).append("\n");
        }
        return sb.toString();
    }

    public String buscarPorNombre(String nombre){
        StringBuilder sb = new StringBuilder();
        for(Estudiante x: lista){
            if (x.getNombre().equalsIgnoreCase(nombre)){
                sb.append(x).append("\n");
            }
        }
        if(sb.length() == 0){
            return "No se encontro Estudiante con ese Nombre";
        }
        return sb.toString();
    }

    public void ordenarPorNotaDescendente() {
        lista.sort((e1, e2) -> Double.compare(e2.getNota(), e1.getNota()));
    }

    public String listarAprobados(){
        StringBuilder sb = new StringBuilder();
        for(Estudiante x: lista){
            if(x.getNota() >= 7){
                sb.append(x).append("\n");
            }
        }
        return sb.toString();
    }

    public String listarReprobados(){
        StringBuilder sb = new StringBuilder();
        for(Estudiante x: lista){
            if(x.getNota() < 7){
                sb.append(x).append("\n");
            }
        }
        return sb.toString();
    }

    public boolean eliminarCodigo(int codigo){
        for(Estudiante x: lista){
            if(x.getCodigo() == codigo){
                lista.remove(x);
                return true;
            }
        }
        return false;
    }



}
