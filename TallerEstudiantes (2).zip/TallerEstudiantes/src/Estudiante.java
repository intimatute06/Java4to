public class Estudiante {
    private String nombre;
    private double nota;
    private int codigo;

    public Estudiante(String nombre, double nota, int codigo) {
        this.nombre = nombre;
        this.nota = nota;
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public double getNota() {
        return nota;
    }

    public int getCodigo() {
        return codigo;
    }

    @Override
    public String toString() {
        return "Estudiante" +
                ", nombre: " + nombre +
                ", nota: " + nota +
                ", codigo: " + codigo ;
    }
}
