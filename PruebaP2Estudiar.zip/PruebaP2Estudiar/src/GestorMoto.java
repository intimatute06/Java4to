import java.util.ArrayList;

public class GestorMoto {

    ArrayList<Motocicleta> lista;
    public GestorMoto() {
        lista = new ArrayList<>();
        lista.add(new Motocicleta(1001, "Yamaha", 300, "Rojo", 12000));
        lista.add(new Motocicleta(1002, "Honda", 500, "Negro", 15000));
        lista.add(new Motocicleta(1003, "Suzuki", 300, "Azul", 18000));
        lista.add(new Motocicleta(1004, "Kawasaki", 1000, "Verde", 20000));
        lista.add(new Motocicleta(1005, "Honda", 800, "Blanco", 25000));

    }


    public void ingresaroModificarmoto(Motocicleta n){
        for( int i = 0;i < lista.size(); i++){
            if(lista.get(i).getCodigo() == n.getCodigo()){
                lista.set(i, n);
                return;
            }
        }
        lista.add(n);
        return;
    }

    public void ordenarPorColor() {
        lista.sort((m1, m2) -> m1.getColor().compareToIgnoreCase(m2.getColor()));
    }

    public void ordenarPorPrecio() {
        lista.sort((m1, m2) -> Float.compare(m1.getPrecio(), m2.getPrecio()));
    }

    public String mostrar(){
        StringBuilder sb = new StringBuilder();
        for (Motocicleta m : lista) {
            sb.append(m).append("\n");
        }
        return sb.toString();
    }


}
