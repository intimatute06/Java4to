import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JTabbedPane tbdIngreso;
    private JTextField txtCodigo;
    private JComboBox cboMarca;
    private JComboBox cboCilindraje;
    private JComboBox cboColor;
    private JTextField txtPrecio;
    private JButton agregarOModificarButton;
    private JButton mostrarButton;
    private JPanel tbdMostrarYClasificar;
    private JTextArea txtMostrar;
    private JTextArea txtColor;
    private JButton btnOrdenarColor;
    private JButton btnOrdenarPrecio;
    private JList lstPrecio;
    GestorMoto gestor = new GestorMoto();

    public Ventana() {
        txtMostrar.setText(gestor.mostrar());

        agregarOModificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String codigoStr = txtCodigo.getText().trim();
                String PrecioStr = txtPrecio.getText().trim();

                try {
                    if (PrecioStr.isEmpty() || codigoStr.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Llene todos los campos");
                        return;
                    }
                    if (codigoStr.length() != 4) {
                        JOptionPane.showMessageDialog(null, "El codigo debe tener 4 digitos");
                        return;
                    }
                    int precio = Integer.parseInt(PrecioStr);
                    if(precio < 1500 || precio > 30000){
                        JOptionPane.showMessageDialog(null, "El precio debe estar entre 1500 y 30000");
                        return;
                    }
                    Motocicleta nuevo = new Motocicleta(
                            Integer.parseInt(txtCodigo.getText().trim()),
                            cboMarca.getSelectedItem().toString(),
                            Integer.parseInt(cboCilindraje.getSelectedItem().toString()),
                            cboColor.getSelectedItem().toString(),
                            Float.parseFloat(txtPrecio.getText().trim())
                    );

                    gestor.ingresaroModificarmoto(nuevo);
                    JOptionPane.showMessageDialog(null, "Motocicleta agregada o modificada correctamente");



                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Ocurrió un error ");
                }






            }
        });
        mostrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtMostrar.setText(gestor.mostrar());
            }
        });
        btnOrdenarColor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gestor.ordenarPorColor();
                txtColor.setText(gestor.mostrar());
            }
        });
        btnOrdenarPrecio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gestor.ordenarPorPrecio();
                lstPrecio.setListData(gestor.mostrar().split("\n"));
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }
}
