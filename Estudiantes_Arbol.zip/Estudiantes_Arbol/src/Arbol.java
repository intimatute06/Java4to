public class Arbol {
    private Nodo raiz;
    public Arbol() {
        raiz = null;
    }
    private void insertar(Nodo actual, Estudiante dato){
        if (dato.getCalificacion() < actual.getEstudiante().getCalificacion()) {
            if (actual.getIzquierda() == null) {
                actual.setIzquierda(new Nodo(dato));
            } else {
                insertar(actual.getIzquierda(), dato);
            }
        } else {
            if (actual.getDerecha() == null) {
                actual.setDerecha(new Nodo(dato));
            } else {
                insertar(actual.getDerecha(), dato);
            }
        }
    }

    public void insertar(Estudiante dato){
        if (raiz == null){
            raiz = new Nodo(dato);


        }else{
            insertar(raiz,dato);
        }


    }

    private String inOrden(Nodo actual){
        if (actual != null){
            return inOrden(actual.getDerecha()) + actual.getEstudiante() + inOrden(actual.getIzquierda());
        } else {
            return "";
        }
    }



    public String inOrden(){
        if (raiz==null){
            return "No hay elementos en el arbol";
        }else{
            return inOrden(raiz);
        }
    }

    public Estudiante buscar(int codigo){
        return buscar(raiz,codigo);
    }

    private Estudiante buscar(Nodo actual, int codigo){
        if(actual == null){
            return null;
        }
        if (codigo == actual.getEstudiante().getCodigo()){
            return actual.getEstudiante();
        } else if (codigo < actual.getEstudiante().getCodigo()) {
            return buscar(actual.getIzquierda(),codigo);

        }else{
            return buscar(actual.getDerecha(),codigo);
        }
    }

    public boolean editar(int codigo, String nuevoNombre, double nuevaCalificacion){
        Estudiante estudiante = buscar(codigo);
        if (estudiante != null){
            estudiante.setNombre(nuevoNombre);
            estudiante.setCalificacion(nuevaCalificacion);
            return true;

        }
        return false;
    }






}
