import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextField txtNombre;
    private JTextField txtCalificacion;
    private JTextField txtCodigo;
    private JButton btnAgregar;
    private JButton btnBuscar;
    private JButton btnEditar;
    private JTextArea txtMostrar;
    Arbol arbol = new Arbol();

    public Ventana() {
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText().trim();
                 String calificacionStr = txtCalificacion.getText().trim();
                String codigoStr = txtCodigo.getText().trim();
                if (nombre.isEmpty() ||calificacionStr.isEmpty() || codigoStr.isEmpty()){
                    JOptionPane.showMessageDialog(null,"LLena todos los compos");
                    return;
                }
                try {
                    double calificacion = Double.parseDouble(calificacionStr);
                    int codigo = Integer.parseInt(codigoStr);
                    if (codigo %5 != 0){
                        JOptionPane.showMessageDialog(null,"El codigo debe ser multiplo de 5");
                         return;
                    }
                    if (calificacion < 0 || calificacion > 10 ){
                        JOptionPane.showMessageDialog(null,"La calificacion debe estar entr 0 y 10");
                       return;
                    }
                    Estudiante nuevo = new Estudiante(nombre,calificacion,codigo);
                    arbol.insertar(nuevo);
                    JOptionPane.showMessageDialog(null, "Estudiante agregado correctamente");
                    txtMostrar.setText(arbol.inOrden());




                } catch (NumberFormatException ex) {
                   JOptionPane.showMessageDialog(null,"La  nota y el id deben ser validos");
                }

            }
        });
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String codigoStr = txtCodigo.getText().trim();
                if(codigoStr.isEmpty()){
                    JOptionPane.showMessageDialog(null,"Ingresa el codigo a buscar");
                    return;
                }
                try {
                    int codigo = Integer.parseInt(txtCodigo.getText());
                    Estudiante estudiante = arbol.buscar(codigo);
                    if (estudiante != null){
                        txtMostrar.setText(estudiante.toString());
                    }else{
                        JOptionPane.showMessageDialog(null,"Estudiante no encontrado");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,"El codigo esta incorrecto");
                }


            }
        });
        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText().trim();
                String calificacionStr = txtCalificacion.getText().trim();
                String codigoStr = txtCalificacion.getText().trim();
                if (nombre.isEmpty() || calificacionStr.isEmpty()){
                    JOptionPane.showMessageDialog(null,"Llena todos los campos");
                    return;

                }
                try {
                    double calificacion = Double.parseDouble(calificacionStr);
                    int codigo = Integer.parseInt(codigoStr);
                    if (calificacion < 0 || calificacion > 10){
                        JOptionPane.showMessageDialog(null,"Calificacion no permitida");
                        return;
                    }
                    boolean editado = arbol.editar(codigo,nombre,calificacion);
                    if (editado){
                        JOptionPane.showMessageDialog(null,"Estudiante editado");
                        txtMostrar.setText(arbol.inOrden());

                    }else{
                        JOptionPane.showMessageDialog(null,"Estudiante no encontrado o no editado");
                    }
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(null,"La nota y el codigo deben ser validos");
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }
}
