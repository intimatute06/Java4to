public class Nodo {
    private Estudiante estudiante;
    private Nodo izquierda;
    private Nodo derecha;

    public Nodo(Estudiante estudiante) {
        this.estudiante = estudiante;
        this.izquierda = null;
        this.derecha = null;

    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Nodo getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(Nodo izquierda) {
        this.izquierda = izquierda;
    }

    public Nodo getDerecha() {
        return derecha;
    }

    public void setDerecha(Nodo derecha) {
        this.derecha = derecha;
    }
}
