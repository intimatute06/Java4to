public class Nodo {
    private Computador computador;
    private Nodo izquierda;
    private Nodo derecha;

    public Nodo(Computador computador) {
        this.computador = computador;
        this.izquierda = null;
        this.derecha = null;
    }

    public Computador getComputador() {
        return computador;
    }

    public void setComputador(Computador computador) {
        this.computador = computador;
    }

    public Nodo getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(Nodo izquierda) {
        this.izquierda = izquierda;
    }

    public Nodo getDerecha() {
        return derecha;
    }

    public void setDerecha(Nodo derecha) {
        this.derecha = derecha;
    }
}
