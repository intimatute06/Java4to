import java.util.Stack;

public class Pila {
    private Stack<String> coleccion;
    private final int LIMITE = 10;

    public Pila(){
        coleccion = new Stack<String>();
    }

    public void insertar(String dato){
        if (coleccion.size() >= LIMITE) {
            throw new IllegalStateException("La pila ya contiene 10 elementos. No se puede agregar más.");
        }
        coleccion.push(dato);
    }

    public String extraer(){
        if (coleccion.isEmpty()) {
            return "Pila vacía";
        }
        return coleccion.pop();
    }

    public String cima(){
        return coleccion.peek();
    }

    @Override
    public String toString() {
        StringBuilder lista = new StringBuilder();
        for(int i = coleccion.size() - 1; i >= 0; i--){
            lista.append(coleccion.get(i)).append("\n");
        }
        return lista.toString();
    }
}
