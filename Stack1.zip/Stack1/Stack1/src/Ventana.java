import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextArea txtCodigo;
    private JButton btnComprobarButton;

    public Ventana() {
        btnComprobarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Pila pilas = new Pila();
                String texto = txtCodigo.getText();
                boolean correcto = true;

                for (int i = 0; i < texto.length(); i++) {
                    char letra = texto.charAt(i);

                    if (letra == '(' || letra == '{' || letra == '[') {
                        pilas.insertar(String.valueOf(letra));
                    } else if (letra == ')' || letra == '}' || letra == ']') {
                        if (pilas.esVacia()) {
                            correcto = false;
                            break;
                        }

                        char apertura = pilas.extraer().charAt(0);
                        if (!coinciden(apertura, letra)) {
                            correcto = false;
                            break;
                        }
                    }
                }

                if (correcto && pilas.esVacia()) {
                    JOptionPane.showMessageDialog(null, "El código está correcto.");
                } else {
                    JOptionPane.showMessageDialog(null, "El código está incorrecto.");
                }
            }

            
            private boolean coinciden(char apertura, char cierre) {
                return (apertura == '(' && cierre == ')') ||
                        (apertura == '{' && cierre == '}') ||
                        (apertura == '[' && cierre == ']');
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
