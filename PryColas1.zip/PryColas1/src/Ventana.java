import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Year;

public class Ventana {

    private JPanel principal;
    private JComboBox cboMarca;
    private JTextField txtAnio;
    private JButton btnEncolar;
    private JButton btnDesencolar;
    private JTextArea txtListado;
    private JLabel lblPago;
    private ColaAutos autos = new ColaAutos();



    public Ventana() {
        btnEncolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String marca = cboMarca.getSelectedItem().toString();
                    int anio = Integer.parseInt(txtAnio.getText());
                    int anioActual = Year.now().getValue();

                    if (anio < 0) {
                        JOptionPane.showMessageDialog(null, "No está permitido ingresar años negativos.");
                        return;
                    }

                    if (anio > anioActual) {
                        JOptionPane.showMessageDialog(null, "No está permitido ingresar un año mayor al actual (" + anioActual + ").");
                        return;
                    }

                    autos.encolar(new Auto(marca, anio));
                    txtListado.setText(autos.listarTodos());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese un año válido.");
                }
            }
        });
        btnDesencolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Auto atendido = autos.desencolar();
                    double pago = atendido.calcularPago();
                    lblPago.setText("Ultimo Auto Atendido: "+atendido.toString()+"\tPago: "+pago);

                    txtListado.setText(autos.listarTodos());
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }


            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.pack();
        frame.setSize(600,800);
        frame.setVisible(true);
    }
}
